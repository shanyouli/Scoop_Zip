"File Descriptions" plugin for Total Commander
----------------------------------------------
This content plugin allows to display file descriptions:

- descriptions from Descript.ion/Files.bbs;
- for text files: file contents;
- for executables/dlls: version information;
- for HTML files: contents of Title/Meta tags;
- for URL files: target location.


Installation
------------
1. With TC 6.50+, just open archive and TC will install plugin automatically.

2. Go to Configuration -> Options -> Custom columns;
   create new view named "Descriptions" and add several columns to it;
   for each column press "+" and select some field from FileDiz list.

3. Turn on custom view:
   Show -> Custom columns mode -> Descriptions.


(c) Alexey Torgashin
www.uvviewsoft.com
